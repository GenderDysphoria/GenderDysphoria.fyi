---
date: "2020-01-26T20:41:55.827Z"
title: "How Gender Dysphoria Manifests: Existential Dysphoria"
linkTitle: "Existential Dysphoria"
description: "I don't regret the things I have done, I regret the things I didn't do when I had the chance."
classes:
  - gdb
preBody: '_disclaimer'
siblings:
  prev: /gdb/presentational-dysphoria
  prevCaption: Presentational Dysphoria
  next: /gdb/managed-dysphoria
  nextCaption: Managed Dysphoria
redirect: /gdb/existential-dysphoria
---

Redirecting...

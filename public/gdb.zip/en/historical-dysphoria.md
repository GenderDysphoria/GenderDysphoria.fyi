---
date: "2020-01-26T20:41:55.827Z"
title: "How Gender Dysphoria Manifests: Existential Dysphoria"
linkTitle: "Existential Dysphoria"
description: "I don't regret the things I have done, I regret the things I didn't do when I had the chance."
classes:
  - gdb
preBody: '_disclaimer'
siblings:
  prev: /en/presentational-dysphoria
  prevCaption: Presentational Dysphoria
  next: /en/managed-dysphoria
  nextCaption: Managed Dysphoria
redirect: /en/existential-dysphoria
---

Redirecting...
